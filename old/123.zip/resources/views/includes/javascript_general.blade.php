<script src="{{ asset('public/js/core.min.js') }}"></script>
<script src="{{ asset('public/js/jqueryTimeago.js') }}"></script>
<script src="{{ asset('public/js/app-functions.js') }}"></script>
<script src="https://js.stripe.com/v3/"></script>
