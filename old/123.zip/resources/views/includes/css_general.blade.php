<link href="{{ asset('public/css/core.css') }}" rel="stylesheet">
<link href="{{ asset('public/css/styles.css') }}" rel="stylesheet">

<script type="text/javascript">
    // URL BASE
    var URL_BASE = "{{ url('/') }}";
    // ReadMore
    var ReadMore = "{{ trans('misc.view_more') }}";
    var ReadLess = "{{ trans('misc.view_less') }}";
 </script>
