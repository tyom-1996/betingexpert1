

 <?php
	if (str_slug( $key->title ) == '' ) {
		$slugUrl  = '';
	} else {
		$slugUrl  = '/'.str_slug( $key->title );
	}

	$url = url('campaign',$key->id).$slugUrl;
	$percentage = number_format($key->funds / $key->goal * 100, 2, '.', '');

  // Deadline
	$timeNow = strtotime(Carbon\Carbon::now());

	if ($key->deadline != '') {
	    $deadline = strtotime($key->deadline);

		$date = strtotime($key->deadline);
	    $remaining = $date - $timeNow;

		$days_remaining = floor($remaining / 86400);
	}
?>

<div class="siderproject__item" onclick="window.location.href = '/campaign/<?php echo e($key->id, false); ?>/<?php echo e($key->title, false); ?>'">
	<div class="border__slide">
		<div class="item__column">
			<div class="slide__ico">
				<img src="<?php echo e(asset('public/campaigns/small').'/'.$key->small_image, false); ?>" alt="">
			</div>
			<div class="item__like">
				<div class="like__text">funding</div>
				<div class="like__ico">
					<a href="">
						<img src="public/img/heart.png" alt="">
					</a>
				</div>
			</div>
			<div class="item__info">
				<div class="info__title"><?php echo e($key->title, false); ?></div>
				<div class="info__subtitle"><?php echo e(str_limit(strip_tags($key->description), 120, '...'), false); ?></div>
			</div>
		</div>
		
		<div class="item__progress">
			<div class="progress__title">
			<?php if(isset($key->category->id ) && $key->category->mode == 'on'): ?>
				<a href="<?php echo e(url('category', $key->category->slug), false); ?>" class="text-muted"><i class="far fa-folder-open"></i> <?php echo e($key->category->name, false); ?></a>
			<?php endif; ?>
			</div>
				<div class="progress__subtitle">
				<div class="sub__money"><?php echo e(App\Helper::amountFormat($key->funds), false); ?> <span>usd raised</span></div>
				<div class="sub__procent"><?php echo e($percentage, false); ?>%</div>
			</div> 
			<div class="progress__bar"></div>
			<div class="progress__time">
				<!--<div class=""><img src="public/img/time.png" alt=""></div> -->
				<div class="time__info">
					<?php if(isset( $deadline ) && $key->finalized == 0): ?>

					  <?php if($days_remaining > 0 ): ?>
						<i class="far fa-clock text-success"></i> <?php echo e($days_remaining, false); ?> <?php echo e(trans('misc.days_left'), false); ?>

					  <?php elseif($days_remaining == 0 ): ?>
						<i class="far fa-clock text-warning"></i> <?php echo e(trans('misc.last_day'), false); ?>

					  <?php else: ?>
						<i class="far fa-clock text-danger"></i> <?php echo e(trans('misc.no_time_anymore').$days_remaining, false); ?>

					  <?php endif; ?>
					<?php endif; ?>
					<?php if($key->finalized == 1): ?>
					  <i class="far fa-clock text-danger"></i> <?php echo e(trans('misc.campaign_ended'), false); ?>

					  <?php endif; ?>

					  <?php if(!isset( $deadline) && $key->finalized == 0): ?>
						<i class="fa fa-infinity text-success"></i> <?php echo e(trans('misc.no_deadline'), false); ?>

						<?php endif; ?>
				</div>
			</div>
		</div>
		</a>
	</div>
</div>
<?php /**PATH /var/www/www-root/data/www/resources/views/includes/list-campaigns.blade.php ENDPATH**/ ?>