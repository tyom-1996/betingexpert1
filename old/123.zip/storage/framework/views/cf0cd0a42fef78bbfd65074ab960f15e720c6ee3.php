<?php $__env->startSection('css'); ?>
<style>
/**
 * The CSS shown here will not be introduced in the Quickstart guide, but shows
 * how you can use CSS to style your Element's container.
 */
.StripeElement {
  box-sizing: border-box;
  height: 40px;
  padding: 11px 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: white;
  -webkit-transition: box-shadow 150ms ease;
  transition: box-shadow 150ms ease;
  margin-bottom: 10px
}

.StripeElement--focus {
	border-color: #f45302;
}

.StripeElement--invalid {
  border-color: #fa755a;
}

.StripeElement--webkit-autofill {
  background-color: #fefde5 !important;
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="jumbotron text-center">
      <div class="container wrap-jumbotron position-relative">
      	<h1 class="text-break"><?php echo e(trans('misc.pay_success'), false); ?></h1>
		<a href="/index.php"><?php echo e(trans('misc.back_to_front'), false); ?></a>
      </div>
    </div>

<!-- Container
============================= -->
<div class="container py-5">

  <div class="row">

</div><!-- Row -->

 </div><!-- container wrap-ui -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/resources/views/default/success.blade.php ENDPATH**/ ?>