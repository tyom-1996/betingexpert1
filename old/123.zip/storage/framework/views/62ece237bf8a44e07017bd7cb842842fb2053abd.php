<script src="<?php echo e(asset('public/js/core.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('public/js/jqueryTimeago.js'), false); ?>"></script>
<script src="<?php echo e(asset('public/js/app-functions.js'), false); ?>"></script>
<script src="https://js.stripe.com/v3/"></script>
<?php /**PATH /var/www/www-root/data/www/resources/views/includes/javascript_general.blade.php ENDPATH**/ ?>