<div class="header">
        <div class="container">
    
            <div class="header__inner">
    
    
                <div class="header__logo">

      <a class="navbar-brand" href="<?php echo e(url('/'), false); ?>">
        <img src="<?php echo e(asset('public/img/logo.png'), false); ?>" style="max-width: 100px;"class="align-baseline" alt="<?php echo e($settings->title, false); ?>" />
      </a>
				
				
				</div>
    
                <div class="menu">
                    <nav class="nav">
                        <div class="nav__left">
                            <a href="" class="nav__link">Explore  <span><i class="arrow down"></i></span></a>
                            <a href="" class="nav__link">What We Do <img src="<?php echo e(asset('public/img/search.png'), false); ?>" alt="">
                            </a>
                        </div>
                        <input type="text">
                        <div class="nav__right">
                            <a href="" class="nav__link">For Entrepreneurs</a>
                            <a href="https://bettingexpert.pro/create/campaign" class="nav__link nav__link--after">Start a Campaign</a>
							
							
							
							<?php if(auth()->guard()->check()): ?>
            <li class="nav-item mr-1 dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="<?php echo e(asset('public/avatar').'/'.auth()->user()->avatar, false); ?>" alt="User" class="rounded-circle avatarUser" width="25" height="25" />
                <?php $name = explode(' ', auth()->user()->name); ?>
                <span class="d-lg-none"><?php echo e(trans('users.my_profile'), false); ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right dd-menu-user" aria-labelledby="dropdown03">

                <?php if(auth()->user()->role == 'admin'): ?>
                <a class="dropdown-item" href="<?php echo e(url('panel/admin'), false); ?>"><?php echo e(trans('admin.admin'), false); ?></a>
                <div class="dropdown-divider"></div>
              <?php endif; ?>

              <a href="<?php echo e(url('dashboard'), false); ?>" class="dropdown-item">
                <?php echo e(trans('admin.dashboard'), false); ?>

                </a>

              <a href="<?php echo e(url('dashboard/campaigns'), false); ?>" class="dropdown-item">
              <?php echo e(trans('misc.campaigns'), false); ?>

                </a>

              <a href="<?php echo e(url('user/likes'), false); ?>" class="dropdown-item">
                <?php echo e(trans('misc.likes'), false); ?>

                </a>

              <a href="<?php echo e(url('account'), false); ?>" class="dropdown-item">
                <?php echo e(trans('users.account_settings'), false); ?>

                </a>
                <div class="dropdown-divider"></div>

              <a href="<?php echo e(url('logout'), false); ?>" class="logout dropdown-item">
                <?php echo e(trans('users.logout'), false); ?>

              </a>

              </div>
            </li>
							 <?php else: ?>
                            <a href="" class="nav__link" data-toggle="modal" data-target="#sign_up">Log In</a>
                            <a href="" class="nav__link" data-toggle="modal" data-target="#exampleModal">Sign Up</a>
							<?php endif; ?>
                        </div>
                    </nav>
                </div>
    
    
            </div>
    
        </div>
    </div>
	
	<?php /**PATH /var/www/www-root/data/www/resources/views/includes/navbar.blade.php ENDPATH**/ ?>