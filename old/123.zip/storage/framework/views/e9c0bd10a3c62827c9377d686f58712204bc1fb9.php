<?php $__env->startSection('title'); ?><?php echo e(trans('misc.add_reward').' - ', false); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?><link rel="stylesheet" href="<?php echo e(asset('public/plugins/datepicker/datepicker3.css'), false); ?>" rel="stylesheet" type="text/css"><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="jumbotron mb-0 bg-sections text-center">
    <div class="container wrap-jumbotron position-relative">
    	<h1><?php echo e(trans('misc.add_reward'), false); ?></h1>
      <p class="mb-0">
        <?php echo e($data->title, false); ?>

      </p>
    </div>
  </div>

<div class="container py-5">
	<div class="row">

    <div class="wrap-container-lg">
	<!-- col-md-8 -->
	<div class="col-md-12">

			<?php echo $__env->make('errors.errors-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- form start -->
    <form method="POST" action="" id="formUpdateCampaign" enctype="multipart/form-data">

    	<input type="hidden" name="_token" value="<?php echo e(csrf_token(), false); ?>">
    	<input type="hidden" name="id" value="<?php echo e($data->id, false); ?>">

      <!-- Start Form Group -->
      <div class="form-group">
        <label><?php echo e(trans('misc.title'), false); ?></label>
          <input type="text" value=""  name="title" autocomplete="off" class="form-control" placeholder="<?php echo e(trans('misc.title'), false); ?>">
        <small class="text-muted"><?php echo e(trans('misc.title_reward_desc'), false); ?></small>

      </div><!-- /.form-group-->

      <div class="form-group">
        <label><?php echo e(trans('misc.amount'), false); ?></label>
        <div class="input-group">
          <div class="input-group-prepend">
            <span class="input-group-text"><?php echo e($settings->currency_symbol, false); ?></span>
          </div>
          <input type="number" min="1" class="form-control onlyNumber" name="amount" autocomplete="off" value="<?php echo e(old('amount'), false); ?>" placeholder="<?php echo e(trans('misc.amount'), false); ?>">
        </div>
      </div>

        <div class="form-group">
            <label><?php echo e(trans('misc.description'), false); ?></label>
            	<textarea name="description" rows="4" id="description" class="form-control" placeholder="<?php echo e(trans('misc.description'), false); ?>"></textarea>
          </div>

          <div class="form-group">
            <label><?php echo e(trans('misc.quantity'), false); ?></label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fa fa-copy"></i></span>
              </div>
              <input type="number" min="1" class="form-control onlyNumber" name="quantity" autocomplete="off" value="<?php echo e(old('quantity'), false); ?>" placeholder="<?php echo e(trans('misc.quantity'), false); ?>">
            </div>
          </div>

          <!-- Start Form Group -->
          <div class="form-group">
            <label><?php echo e(trans('misc.delivery'), false); ?></label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
              </div>
              <input type="text" value="<?php echo e(old('delivery'), false); ?>" id="datepicker" name="delivery" autocomplete="off" class="form-control" placeholder="<?php echo e(trans('misc.delivery'), false); ?>">
            </div>
            <small class="text-muted"><?php echo e(trans('misc.delivery_desc'), false); ?></small>

          </div><!-- /.form-group-->

            <!-- Alert -->
            <div class="alert alert-danger d-none-custom mt-2" id="dangerAlert">
							<ul class="list-unstyled mb-0" id="showErrors"></ul>
						</div><!-- Alert -->

            <div class="alert alert-success d-none-custom mt-2" id="successAlert">
                    <ul class="list-unstyled mb-0" id="success_update">
                      <li><i class="far fa-check-circle mr-1"></i> <?php echo e(trans('misc.success_add_rewards'), false); ?>

                        <a href="<?php echo e(url('campaign',$data->id), false); ?>" class="text-white text-underline"><?php echo e(trans('misc.view_campaign'), false); ?></a>
                      </li>
                    </ul>
                  </div><!-- Alert -->

            <div class="box-footer">
            	<hr />
              <button type="submit" id="buttonUpdateForm" class="btn btn-block btn-lg btn-primary no-hover" data-create="<?php echo e(trans('auth.send'), false); ?>" data-send="<?php echo e(trans('misc.send_wait'), false); ?>"><?php echo e(trans('auth.send'), false); ?></button>
              <div class="btn-block text-center mt-2">
           		<a href="<?php echo e(url('campaign',$data->id), false); ?>" class="text-muted">
           		<i class="fa fa-long-arrow-alt-left"></i>	<?php echo e(trans('auth.back'), false); ?></a>
           </div>
            </div><!-- /.box-footer -->
          </form>
        </div><!-- wrap-center -->
		</div><!-- col-md-12-->

	</div><!-- row -->
</div><!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
	<script src="<?php echo e(asset('public/plugins/datepicker/bootstrap-datepicker.js'), false); ?>" type="text/javascript"></script>

	<script type="text/javascript">

  //Date picker
    $('#datepicker').datepicker({
      autoclose: true,
      format: 'yyyy-mm',
      startView: "months",
      minViewMode: "months",
      startDate: '+1m',
      //endDate: '+30d',
      language: 'en'
    });

    $(".onlyNumber").keypress(function(event) {
        return /\d/.test(String.fromCharCode(event.keyCode));
    });

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/resources/views/campaigns/rewards.blade.php ENDPATH**/ ?>