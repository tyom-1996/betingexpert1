<link href="<?php echo e(asset('public/css/core.css'), false); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/css/styles.css'), false); ?>" rel="stylesheet">

<script type="text/javascript">
    // URL BASE
    var URL_BASE = "<?php echo e(url('/'), false); ?>";
    // ReadMore
    var ReadMore = "<?php echo e(trans('misc.view_more'), false); ?>";
    var ReadLess = "<?php echo e(trans('misc.view_less'), false); ?>";
 </script>
<?php /**PATH /var/www/www-root/data/www/resources/views/includes/css_general.blade.php ENDPATH**/ ?>