<?php $__env->startSection('title'); ?> <?php echo e(trans('auth.password_recover'), false); ?> -<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="py-5 bg-primary bg-sections">
    <div class="btn-block text-center text-white position-relative">
      <h1><?php echo e(trans('auth.password_recover'), false); ?></h1>
      <p><?php echo e($settings->title, false); ?></p>
    </div>
  </div><!-- container -->

<div class="py-5 bg-white text-center">
<div class="container margin-bottom-40">

	<div class="row">
<!-- Col MD -->
<div class="col-md-12">
	<div class="d-flex justify-content-center">

        <form action="<?php echo e(url('password/email'), false); ?>" method="post" class="login-form text-left <?php if(count($errors) > 0): ?>vivify shake <?php endif; ?>" name="form" id="signup_form">

          <?php echo csrf_field(); ?>

          <?php if($settings->captcha == 'on'): ?>
            <?php echo app('captcha')->render(); ?>
          <?php endif; ?>

          <?php echo $__env->make('errors.errors-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <?php if(session('status')): ?>
  						<div class="alert alert-success">
  							<?php echo e(session('status'), false); ?>

  						</div>
      			<?php endif; ?>

          <div class="form-group">
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fa fa-envelope"></i></span>
              </div>
            <input type="email" class="form-control" required value="<?php echo e(old('email'), false); ?>" name="email" id="email" placeholder="<?php echo e(trans('auth.email'), false); ?>" title="<?php echo e(trans('auth.email'), false); ?>" autocomplete="off">
          </div>
          </div>

          <button type="submit" class="btn btn-block mt-2 py-2 btn-primary font-weight-light"><?php echo e(trans('auth.send'), false); ?></button>
          <?php if($settings->captcha == 'on'): ?>
            <small class="btn-block text-center"><?php echo e(trans('misc.protected_recaptcha'), false); ?> <a href="https://policies.google.com/privacy" target="_blank"><?php echo e(trans('misc.privacy'), false); ?></a> - <a href="https://policies.google.com/terms" target="_blank"><?php echo e(trans('misc.terms'), false); ?></a></small>
          <?php endif; ?>
          <div class="text-center mt-2">
            <a href="<?php echo e(url('login'), false); ?>"><i class="fa fa-long-arrow-alt-left"></i> <?php echo e(trans('auth.back'), false); ?></a>
          </div>
        </form>
     </div><!-- Login Form -->
   </div><!-- /COL MD -->
  </div><!-- ./ -->
  </div><!-- ./ -->
</div>
 <!-- container wrap-ui -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
	<script type="text/javascript">

	<?php if(count($errors) > 0): ?>
    	scrollElement('#dangerAlert');
    <?php endif; ?>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/www-root/data/www/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>